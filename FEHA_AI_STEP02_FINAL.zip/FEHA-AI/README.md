# FEHA AI

Android app written in Kotlin with Jetpack Compose and Gradle.

- Package: `com.feha.ai`
- minSdk 26, targetSdk 35, compileSdk 35
- Android Gradle Plugin 8.7.2, Kotlin 2.0.21, Compose compiler plugin

## Product flavors

Two flavors share one code base, in the `distribution` dimension:

| Flavor | Application ID suffix | `BuildConfig.DISTRIBUTION_CHANNEL` |
|--------|-----------------------|-------------------------------------|
| direct | `.direct`             | `direct`                            |
| play   | none                  | `play`                              |

Examples: `./gradlew assembleDirectDebug`, `./gradlew assemblePlayRelease`.

## Settings and storage

- Preferences (theme, personality, language, voice, speech speed, volume, names) are stored with Preferences DataStore and survive restarts.
- API keys (Gemini, Groq) are stored in EncryptedSharedPreferences with an AES256-GCM master key in the Android Keystore. They are never logged and never hardcoded.
- The Settings screen shows only masked key previews such as `****1234`.

## Build

1. Open the project in Android Studio (Ladybug or newer) and let Gradle sync.
2. Or use `./gradlew` directly. On first run it downloads `gradle/wrapper/gradle-wrapper.jar`. If that download fails, run `gradle wrapper --gradle-version 8.9` once with a local Gradle install.

Unit tests: `./gradlew testDirectDebugUnitTest`.

The voice engine is not implemented. `voice/VoiceSessionManager.kt` is an integration hook only.
