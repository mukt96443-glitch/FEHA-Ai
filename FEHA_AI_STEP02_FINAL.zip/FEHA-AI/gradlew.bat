@echo off
setlocal
cd /d "%~dp0"
if not exist "gradle\wrapper\gradle-wrapper.jar" (
    where gradle >nul 2>nul || (echo gradle-wrapper.jar is missing. Install Gradle 8.9 and run: gradle wrapper --gradle-version 8.9 & exit /b 1)
    call gradle wrapper --gradle-version 8.9 || exit /b 1
)
java -classpath "gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
