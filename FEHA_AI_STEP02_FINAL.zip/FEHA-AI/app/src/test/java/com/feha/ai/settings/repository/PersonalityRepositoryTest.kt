package com.feha.ai.settings.repository

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.feha.ai.settings.keys.ApiKeyStore
import com.feha.ai.settings.keys.ApiProvider
import com.feha.ai.settings.model.Personality
import com.feha.ai.settings.storage.NovaPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class PersonalityRepositoryTest {

    @get:Rule
    val tmp = TemporaryFolder()

    /** In-memory key store. Stands in for the encrypted store in JVM tests. */
    private class FakeApiKeyStore : ApiKeyStore {
        private val keys = mutableMapOf<ApiProvider, String>()
        override fun getKey(provider: ApiProvider): String? = keys[provider]
        override fun saveKey(provider: ApiProvider, key: String) { keys[provider] = key }
        override fun clearKey(provider: ApiProvider) { keys.remove(provider) }
    }

    private fun repository(scope: CoroutineScope, keys: ApiKeyStore): PersonalityRepository {
        val store = PreferenceDataStoreFactory.create(
            scope = scope,
            produceFile = { File(tmp.root, "repo.preferences_pb") }
        )
        return PersonalityRepository(NovaPreferences(store), keys)
    }

    @Test
    fun savesTrimmedKeyAndExposesOnlyMask() = runBlocking {
        val keys = FakeApiKeyStore()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            val repo = repository(scope, keys)
            assertTrue(repo.saveApiKey(ApiProvider.GEMINI, "  AIzaTestKey1234  "))
            assertEquals("AIzaTestKey1234", keys.getKey(ApiProvider.GEMINI))
            assertEquals("****1234", repo.maskedApiKey(ApiProvider.GEMINI))
        } finally {
            scope.cancel()
        }
    }

    @Test
    fun rejectsBlankAndMalformedKeys() = runBlocking {
        val keys = FakeApiKeyStore()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            val repo = repository(scope, keys)
            assertFalse(repo.saveApiKey(ApiProvider.GROQ, "   "))
            assertFalse(repo.saveApiKey(ApiProvider.GROQ, "bad key with spaces"))
            assertNull(keys.getKey(ApiProvider.GROQ))
        } finally {
            scope.cancel()
        }
    }

    @Test
    fun clearRemovesKeyAndMask() = runBlocking {
        val keys = FakeApiKeyStore()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            val repo = repository(scope, keys)
            repo.saveApiKey(ApiProvider.GEMINI, "AIzaTestKey1234")
            repo.clearApiKey(ApiProvider.GEMINI)
            assertNull(keys.getKey(ApiProvider.GEMINI))
            assertEquals("", repo.maskedApiKey(ApiProvider.GEMINI))
        } finally {
            scope.cancel()
        }
    }

    @Test
    fun settingsUpdatesArePersistedThroughRepository() = runBlocking {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            val repo = repository(scope, FakeApiKeyStore())
            repo.updateSettings { it.copy(personality = Personality.FUNNY, username = "Ayesha") }
            val s = repo.settings.first()
            assertEquals(Personality.FUNNY, s.personality)
            assertEquals("Ayesha", s.username)
        } finally {
            scope.cancel()
        }
    }
}
