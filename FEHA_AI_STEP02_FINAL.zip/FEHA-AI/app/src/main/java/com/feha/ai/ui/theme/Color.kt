package com.feha.ai.ui.theme

import androidx.compose.ui.graphics.Color

val FehaBlue = Color(0xFF1E5EFF)
val FehaTeal = Color(0xFF14B8A6)
val FehaBlueLight = Color(0xFF9CC3FF)
val FehaTealLight = Color(0xFF6FD6C9)
val FehaBackgroundLight = Color(0xFFF7F9FC)
val FehaBackgroundDark = Color(0xFF0F1419)
val FehaSurfaceDark = Color(0xFF171C22)
