package com.feha.ai.core

object AssistantBrand {
    const val NAME = "FEHA"
    const val FULL_NAME = "FEHA AI"
}
