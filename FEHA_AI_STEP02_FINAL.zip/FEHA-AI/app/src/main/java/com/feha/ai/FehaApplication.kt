package com.feha.ai

import android.app.Application

class FehaApplication : Application() {
    val container: AppContainer by lazy { AppContainer(this) }
}
