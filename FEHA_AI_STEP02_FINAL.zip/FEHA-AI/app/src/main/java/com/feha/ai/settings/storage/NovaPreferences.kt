package com.feha.ai.settings.storage

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.feha.ai.core.AssistantBrand
import com.feha.ai.settings.model.AppLanguage
import com.feha.ai.settings.model.DEFAULT_SPEECH_SPEED
import com.feha.ai.settings.model.DEFAULT_VOICE_NAME
import com.feha.ai.settings.model.DEFAULT_VOICE_VOLUME
import com.feha.ai.settings.model.NovaSettings
import com.feha.ai.settings.model.Personality
import com.feha.ai.settings.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

/** Persists non-secret settings in Preferences DataStore. Survives app restarts. */
class NovaPreferences(private val dataStore: DataStore<Preferences>) {

    val settings: Flow<NovaSettings> = dataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs -> prefs.toNovaSettings() }

    /** Atomic read-modify-write. */
    suspend fun update(transform: (NovaSettings) -> NovaSettings) {
        dataStore.edit { prefs ->
            val updated = transform(prefs.toNovaSettings()).sanitized()
            prefs.writeNovaSettings(updated)
        }
    }
}

private object NovaPreferenceKeys {
    val ASSISTANT_NAME = stringPreferencesKey("assistant_name")
    val USERNAME = stringPreferencesKey("username")
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val PERSONALITY = stringPreferencesKey("personality")
    val LANGUAGE = stringPreferencesKey("language")
    val VOICE_NAME = stringPreferencesKey("voice_name")
    val SPEECH_SPEED = floatPreferencesKey("speech_speed")
    val VOICE_VOLUME = floatPreferencesKey("voice_volume")
}

private fun Preferences.toNovaSettings(): NovaSettings = NovaSettings(
    assistantName = this[NovaPreferenceKeys.ASSISTANT_NAME] ?: AssistantBrand.NAME,
    username = this[NovaPreferenceKeys.USERNAME] ?: "",
    themeMode = ThemeMode.fromName(this[NovaPreferenceKeys.THEME_MODE]),
    personality = Personality.fromName(this[NovaPreferenceKeys.PERSONALITY]),
    language = AppLanguage.fromName(this[NovaPreferenceKeys.LANGUAGE]),
    voiceName = this[NovaPreferenceKeys.VOICE_NAME] ?: DEFAULT_VOICE_NAME,
    speechSpeed = this[NovaPreferenceKeys.SPEECH_SPEED] ?: DEFAULT_SPEECH_SPEED,
    voiceVolume = this[NovaPreferenceKeys.VOICE_VOLUME] ?: DEFAULT_VOICE_VOLUME
).sanitized()

private fun MutablePreferences.writeNovaSettings(settings: NovaSettings) {
    this[NovaPreferenceKeys.ASSISTANT_NAME] = settings.assistantName
    this[NovaPreferenceKeys.USERNAME] = settings.username
    this[NovaPreferenceKeys.THEME_MODE] = settings.themeMode.name
    this[NovaPreferenceKeys.PERSONALITY] = settings.personality.name
    this[NovaPreferenceKeys.LANGUAGE] = settings.language.name
    this[NovaPreferenceKeys.VOICE_NAME] = settings.voiceName
    this[NovaPreferenceKeys.SPEECH_SPEED] = settings.speechSpeed
    this[NovaPreferenceKeys.VOICE_VOLUME] = settings.voiceVolume
}
