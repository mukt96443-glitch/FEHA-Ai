package com.feha.ai.settings.keys

enum class ApiProvider(val prefKey: String, val label: String) {
    GEMINI("gemini_api_key", "Gemini"),
    GROQ("groq_api_key", "Groq")
}

/** Storage for user-provided API keys. Implementations must encrypt at rest. */
interface ApiKeyStore {
    fun getKey(provider: ApiProvider): String?
    fun saveKey(provider: ApiProvider, key: String)
    fun clearKey(provider: ApiProvider)
}

object ApiKeyFormat {
    private const val VISIBLE_SUFFIX = 4
    private const val MASK_PREFIX = "****"

    fun normalize(raw: String): String = raw.trim()

    fun isPlausible(normalized: String): Boolean =
        normalized.isNotEmpty() && normalized.none { it.isWhitespace() }

    /** Safe for display: shows at most the last four characters. */
    fun mask(key: String?): String {
        val trimmed = key?.trim().orEmpty()
        if (trimmed.isEmpty()) return ""
        return if (trimmed.length <= VISIBLE_SUFFIX) MASK_PREFIX
        else MASK_PREFIX + trimmed.takeLast(VISIBLE_SUFFIX)
    }
}
