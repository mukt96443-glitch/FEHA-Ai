package com.feha.ai.settings.repository

import com.feha.ai.settings.keys.ApiKeyFormat
import com.feha.ai.settings.keys.ApiKeyStore
import com.feha.ai.settings.keys.ApiProvider
import com.feha.ai.settings.model.NovaSettings
import com.feha.ai.settings.storage.NovaPreferences
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Single entry point for settings and API keys. The UI sees only settings and masked keys.
 * Raw keys are exposed only through [readApiKeyForRequest], for future network clients.
 */
class PersonalityRepository(
    private val preferences: NovaPreferences,
    private val apiKeys: ApiKeyStore,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    val settings: Flow<NovaSettings> = preferences.settings

    suspend fun updateSettings(transform: (NovaSettings) -> NovaSettings) {
        withContext(ioDispatcher) { preferences.update(transform) }
    }

    /** Returns true if the key was saved. Blank or malformed keys are rejected. */
    suspend fun saveApiKey(provider: ApiProvider, rawKey: String): Boolean =
        withContext(ioDispatcher) {
            val normalized = ApiKeyFormat.normalize(rawKey)
            if (!ApiKeyFormat.isPlausible(normalized)) {
                false
            } else {
                apiKeys.saveKey(provider, normalized)
                true
            }
        }

    suspend fun clearApiKey(provider: ApiProvider) {
        withContext(ioDispatcher) { apiKeys.clearKey(provider) }
    }

    suspend fun maskedApiKey(provider: ApiProvider): String =
        withContext(ioDispatcher) { ApiKeyFormat.mask(apiKeys.getKey(provider)) }

    /** For network clients only. Never pass the result to UI, logs, or analytics. */
    suspend fun readApiKeyForRequest(provider: ApiProvider): String? =
        withContext(ioDispatcher) { apiKeys.getKey(provider) }
}
