package com.feha.ai.state

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.feha.ai.settings.keys.ApiProvider
import com.feha.ai.settings.model.NovaSettings
import com.feha.ai.settings.repository.PersonalityRepository
import com.feha.ai.voice.VoiceSessionHook
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

enum class AppScreen { HOME, SETTINGS }

enum class SettingsStatus {
    PROFILE_SAVED,
    GEMINI_KEY_SAVED,
    GROQ_KEY_SAVED,
    GEMINI_KEY_INVALID,
    GROQ_KEY_INVALID,
    GEMINI_KEY_CLEARED,
    GROQ_KEY_CLEARED
}

/** Compose state holder. Persistence goes through [PersonalityRepository]. */
@Stable
class NovaAppState(
    private val repository: PersonalityRepository,
    private val scope: CoroutineScope,
    private val voiceSessionHook: VoiceSessionHook
) {
    var settings: NovaSettings by mutableStateOf(NovaSettings())
        private set

    var isLoaded: Boolean by mutableStateOf(false)
        private set

    var currentScreen: AppScreen by mutableStateOf(AppScreen.HOME)
        private set

    /** Masked key previews only (for example "****1234"). Raw keys never enter state. */
    var maskedKeys: Map<ApiProvider, String> by mutableStateOf(emptyMap())
        private set

    var statusMessage: SettingsStatus? by mutableStateOf(null)
        private set

    init {
        scope.launch {
            repository.settings.collect { loaded ->
                settings = loaded
                isLoaded = true
                voiceSessionHook.onSettingsApplied(loaded)
            }
        }
        scope.launch { refreshMaskedKeys() }
    }

    fun navigate(screen: AppScreen) {
        currentScreen = screen
    }

    fun updateSettings(transform: (NovaSettings) -> NovaSettings) {
        scope.launch { repository.updateSettings(transform) }
    }

    fun saveProfile(assistantName: String, username: String) {
        scope.launch {
            repository.updateSettings { it.copy(assistantName = assistantName, username = username) }
            statusMessage = SettingsStatus.PROFILE_SAVED
        }
    }

    fun saveApiKey(provider: ApiProvider, rawKey: String) {
        scope.launch {
            val saved = repository.saveApiKey(provider, rawKey)
            refreshMaskedKeys()
            statusMessage = if (saved) savedStatus(provider) else invalidStatus(provider)
        }
    }

    fun clearApiKey(provider: ApiProvider) {
        scope.launch {
            repository.clearApiKey(provider)
            refreshMaskedKeys()
            statusMessage = clearedStatus(provider)
        }
    }

    fun dismissStatus() {
        statusMessage = null
    }

    private suspend fun refreshMaskedKeys() {
        maskedKeys = ApiProvider.entries.associateWith { repository.maskedApiKey(it) }
    }

    private fun savedStatus(provider: ApiProvider): SettingsStatus = when (provider) {
        ApiProvider.GEMINI -> SettingsStatus.GEMINI_KEY_SAVED
        ApiProvider.GROQ -> SettingsStatus.GROQ_KEY_SAVED
    }

    private fun invalidStatus(provider: ApiProvider): SettingsStatus = when (provider) {
        ApiProvider.GEMINI -> SettingsStatus.GEMINI_KEY_INVALID
        ApiProvider.GROQ -> SettingsStatus.GROQ_KEY_INVALID
    }

    private fun clearedStatus(provider: ApiProvider): SettingsStatus = when (provider) {
        ApiProvider.GEMINI -> SettingsStatus.GEMINI_KEY_CLEARED
        ApiProvider.GROQ -> SettingsStatus.GROQ_KEY_CLEARED
    }
}

@Composable
fun rememberNovaAppState(
    repository: PersonalityRepository,
    voiceSessionHook: VoiceSessionHook
): NovaAppState {
    val scope = rememberCoroutineScope()
    return remember(repository, voiceSessionHook) {
        NovaAppState(repository, scope, voiceSessionHook)
    }
}
