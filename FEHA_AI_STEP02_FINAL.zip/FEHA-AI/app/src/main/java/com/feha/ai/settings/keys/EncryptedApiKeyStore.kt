package com.feha.ai.settings.keys

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * API keys encrypted at rest with an AES256-GCM master key held in the Android Keystore.
 * Keys are never logged and never written to DataStore or backups.
 */
class EncryptedApiKeyStore(context: Context) : ApiKeyStore {

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    override fun getKey(provider: ApiProvider): String? =
        prefs.getString(provider.prefKey, null)?.takeIf { it.isNotBlank() }

    override fun saveKey(provider: ApiProvider, key: String) {
        prefs.edit().putString(provider.prefKey, ApiKeyFormat.normalize(key)).apply()
    }

    override fun clearKey(provider: ApiProvider) {
        prefs.edit().remove(provider.prefKey).apply()
    }

    private companion object {
        const val FILE_NAME = "feha_secure_api_keys"
    }
}
