package com.feha.ai.voice

import com.feha.ai.settings.model.NovaSettings

/** Compile-safe hook. The voice engine will receive settings through this interface. */
interface VoiceSessionHook {
    fun onSettingsApplied(settings: NovaSettings)
}

sealed interface VoiceStartResult {
    data object NotImplemented : VoiceStartResult
}

/** Placeholder. No speech recognition or TTS is started in this step. */
class VoiceSessionManager : VoiceSessionHook {

    @Volatile
    var latestSettings: NovaSettings = NovaSettings()
        private set

    override fun onSettingsApplied(settings: NovaSettings) {
        latestSettings = settings
    }

    fun startSession(): VoiceStartResult = VoiceStartResult.NotImplemented

    fun stopSession() {
        // Nothing to stop until the voice engine exists.
    }
}
