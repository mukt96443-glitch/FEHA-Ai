package com.feha.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import com.feha.ai.settings.model.ThemeMode
import com.feha.ai.state.rememberNovaAppState
import com.feha.ai.ui.FehaApp
import com.feha.ai.ui.theme.FehaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as FehaApplication).container

        setContent {
            val state = rememberNovaAppState(
                repository = container.personalityRepository,
                voiceSessionHook = container.voiceSessionManager
            )
            val systemDark = isSystemInDarkTheme()
            val darkTheme = when (state.settings.themeMode) {
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
                ThemeMode.SYSTEM -> systemDark
            }
            FehaTheme(darkTheme = darkTheme) {
                FehaApp(state = state)
            }
        }
    }
}
